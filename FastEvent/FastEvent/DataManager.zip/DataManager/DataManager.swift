//
//  DataManager.swift
//  FastEvent
//
//  Created by Apps4World on 10/10/23.
//

import UIKit
import SwiftUI
import SwiftData
import Foundation
import WidgetKit
import TipKit

/// Main data manager for the app
class DataManager: NSObject, ObservableObject {

    /// Dynamic properties that the UI will react to
    @Published var events: [EventModel] = [EventModel]()
    @Published var fullScreenMode: FullScreenMode?

    /// Dynamic properties that the UI will react to AND store values in UserDefaults
    @AppStorage("createdWidgetsCount") var createdWidgetsCount: Int = 0
    @AppStorage("didSaveDefaultEvents") var didSaveDefaultEvents: Bool = false
    @AppStorage("selectedWidgetId", store: AppConfig.userDefaults) var selectedWidgetId: String = ""
    @AppStorage(AppConfig.premiumVersion, store: AppConfig.userDefaults) var isPremiumUser: Bool = false

    /// SwiftData model container
    private var container: ModelContainer?

    /// Default initializer
    init(preview: Bool = true) {
        super.init()
        guard preview == false else {
            let previewConfiguration = ModelConfiguration(for: EventModel.self, isStoredInMemoryOnly: true)
            container = try? ModelContainer(for: EventModel.self, configurations: previewConfiguration)
            return
        }
        let groupContainer = ModelConfiguration.GroupContainer.identifier(AppConfig.appGroup)
        let configuration = ModelConfiguration(groupContainer: groupContainer)
        container = try? ModelContainer(for: EventModel.self, configurations: configuration)

        defer {
            Task {
                @MainActor in loadSavedEvents()
            }
        }
    }

    /// - Parameter data: event data
    @MainActor func saveEvent(withData data: [EventDataType: String], selectedWidgetId: String) {
        var events = FetchDescriptor<EventModel>()
        events.predicate = #Predicate { $0.id == selectedWidgetId }
        if let matchingResult = try? self.container?.mainContext.fetch(events).first {
            // Update existing event
            var eventData = data
            eventData[.dateCreated] = Date().string
            self.updateEvent(withData: eventData, for: matchingResult)
        } else {
            // Create a new event
            var eventData = data
            eventData[.dateCreated] = Date().string
            let event: EventModel = EventModel(id: UUID().uuidString, data: eventData)
            self.container?.mainContext.insert(event)
        }
        self.loadSavedEvents()
    }
    
    @MainActor func updateEvent(withData data: [EventDataType: String], for event: EventModel) {
        // Update the event with new data
        var updatedEventData = event.data
        updatedEventData.merge(data, uniquingKeysWith: { _, new in new })
        event.data = updatedEventData

        // Save the changes
        do {
            try container?.mainContext.save()
            self.loadSavedEvents()
            WidgetCenter.shared.reloadAllTimelines()
            try Tips.configure([.displayFrequency(.immediate), .datastoreLocation(.applicationDefault)])
        } catch {
            print("Error updating event: \(error.localizedDescription)")
        }
    }
    
    func getSelectedWidget(withId widgetId: String) -> EventModel? {
        if widgetId == selectedWidgetId {
            return events.first { $0.id == widgetId }
        }
        return nil
    }

    /// Load saved widget events
    @MainActor func loadSavedEvents(completion: ((_ data: [EventModel]) -> Void)? = nil) {
        guard didSaveDefaultEvents else {
            Holiday.allCases.forEach { event in
                container?.mainContext.insert(event.model)
            }
            events = Holiday.allCases.map { $0.model }
            didSaveDefaultEvents = true
            return
        }
        let events = FetchDescriptor<EventModel>()
        DispatchQueue.main.async {
            if let results = try? self.container?.mainContext.fetch(events) {
                var defaultEvents = results.filter({ Holiday.allCases.map({ $0.model.title }).contains($0.title) })
                let customEvents = results.filter({ !defaultEvents.map({ $0.title }).contains($0.title) })
                self.events = customEvents.sorted(by: { $0.dateCreated > $1.dateCreated })

                /// Append default holidays/events
                let defaultHolidays: [String] = Holiday.allCases.map({ $0.rawValue })
                defaultEvents.sort { firstEvent, secondEvent in
                    let firstIndex = defaultHolidays.firstIndex(of: firstEvent.title) ?? Int.max
                    let secondIndex = defaultHolidays.firstIndex(of: secondEvent.title) ?? Int.max
                    return firstIndex < secondIndex
                }
                self.events.append(contentsOf: defaultEvents)

                /// Completion block for the widget
                completion?(self.events)
            }
        }
    }

    #if !(WIDGET)
    /// Delete a widget for a given identifier
    /// - Parameter id: widget data model identifier
    @MainActor func deleteWidget(withId id: String) {
        if selectedWidgetId == id {
            presentAlert(title: "Oops!", message: "You cannot delete this widget. Select another one as primary, then delete this one.", primaryAction: .OK)
        } else {
            var events = FetchDescriptor<EventModel>()
            events.predicate = #Predicate { $0.id == id }
            if let matchingResult = try? self.container?.mainContext.fetch(events).first {
                self.container?.mainContext.delete(matchingResult)
                try? self.container?.mainContext.save()
                self.loadSavedEvents()
            }
        }
    }
    #endif
}

/// Convert color to string
extension Color {
    var string: String {
        var red: CGFloat = 0
        var green: CGFloat = 0
        var blue: CGFloat = 0
        var alpha: CGFloat = 0
        UIColor(self).getRed(&red, green: &green, blue: &blue, alpha: &alpha)
        return "\(red)_\(green)_\(blue)_\(alpha)"
    }
}

/// Convert date to string
extension Date {
    var string: String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
        dateFormatter.locale = Locale(identifier: "en_US")
        return dateFormatter.string(from: self)
    }

    var shortFormat: String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MM/dd/yyyy"
        dateFormatter.locale = Locale(identifier: "en_US")
        return dateFormatter.string(from: self)
    }

    static func create(_ text: [String], index: Int = 0) -> Date {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MM/dd/yyyy"
        var date = dateFormatter.date(from: text[index])!
        while Date() > date {
            date = create(text, index: index + 1)
        }
        return date
    }

    static var yesterday: Date {
        Calendar.current.date(byAdding: .day, value: -1, to: .now)!
    }
}

/// Convert string to date/color
extension String {
    var date: Date? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
        dateFormatter.locale = Locale(identifier: "en_US")
        return dateFormatter.date(from: self)
    }

    var color: Color {
        var red: CGFloat = 0
        var green: CGFloat = 0
        var blue: CGFloat = 0
        var alpha: CGFloat = 0
        components(separatedBy: "_").enumerated().forEach { index, value in
            switch index {
            case 0: red = CGFloat(Double(value) ?? 0)
            case 1: green = CGFloat(Double(value) ?? 0)
            case 2: blue = CGFloat(Double(value) ?? 0)
            case 3: alpha = CGFloat(Double(value) ?? 0)
            default: break
            }
        }
        return Color(uiColor: UIColor(red: red, green: green, blue: blue, alpha: alpha))
    }
}

/// Get the time difference between 2 dates
extension Date {
    var timeDifference: [Calendar.Component: Int] {
        let components: Set<Calendar.Component> = [.month, .day, .hour, .minute]
        let difference: DateComponents = Calendar.current.dateComponents(components, from: Date(), to: self)
        var result: [Calendar.Component: Int] = [:]
        components.forEach { component in
            if let value = difference.value(for: component), value != 0 {
                result[component] = value
            }
        }
        return result
    }
}

#if !(WIDGET)
/// Present an alert from anywhere in the app
func presentAlert(title: String, message: String, primaryAction: UIAlertAction? = nil, secondaryAction: UIAlertAction? = nil, tertiaryAction: UIAlertAction? = nil) {
    DispatchQueue.main.async {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        if let primary = primaryAction { alert.addAction(primary) }
        if let secondary = secondaryAction { alert.addAction(secondary) }
        if let tertiary = tertiaryAction { alert.addAction(tertiary) }
        rootController?.present(alert, animated: true, completion: nil)
    }
}

extension UIAlertAction {
    static var Cancel: UIAlertAction {
        UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
    }

    static var OK: UIAlertAction {
        UIAlertAction(title: "OK", style: .cancel, handler: nil)
    }
}
#endif
